const mongoose = require("mongoose");

//{"id":1,"city":"Neftegorsk","start_date":"4/13/2013","end_date":"5/18/2013","price":"55.82","status":"Seldom","color":"#fd4e19"}
var citySchema = new mongoose.Schema({
    id:{
        type: Number,
        required: 'please enter'
    },
    city:{
        type: String,
        required: 'please enter'
    },
    
    price:{
        type: Number
    },
    status:{
        type: String
    },
    color:{
        type: String
    }
    //,
    // start_date:{
    //     type: Date,
    // },
    // end_date:{
    //     type: Date
    // }
});
mongoose.model('city', citySchema);
