const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');

const CityModel = mongoose.model('city');

router.get('/',function(req,res){
    //res.json('sample text');
    res.render('city/addOrEdit', {viewTitle: "Insert city"});
});

router.get('/ctylist',function(req,res){
    
    console.log('inserting new city..');
    insertCityrecord(req,res);
    CityModel.find((err, docs)=>{
        console.log(docs.length);
        if(!err)
        {
            res.render("city/citylist",{
                list: docs
            });
        }
        else
        {
            console.log('Error in retrieving city list');
        }
    }).limit(5);
});

router.post('/', (req,res)=>{
    
    console.log(req.body);
    insertrecord(req,res);
});


function updateRecord(req,res)
{
    CityModel.findOneAndUpdate({_id:req.body}, req.body, {new:true}, (err,doc)=>{
        if(!err){res.redirect('city/list');}
        else
        {
            if(err.name=='ValidationError')
            {
                handleValidationError(err, req.body);
                res.render("city/addOrEdit",{
                    viewTitle: 'update city',
                    city : req.body
                })
            }
            else{
                console.log('Error during record update', err);
            }
        }
    });
}

router.get('/list',(req,res)=>{
    //res.json('from list');
    console.log('debug /list');
    CityModel.find((err, docs)=>{
        if(!err)
        {
            res.render("city/list",{
                list: docs
            });
        }
        else
        {
            console.log('Error in retrieving city list');
        }
    });

});

router.get('/:id', (req,res)=>{
    CityModel.findById(req.params.id, (err,doc)=>{
        if(!err)
        {
            res.render("city/addOrEdit",{
                viewTitle : "Update city", city:doc
            });
        }

    });
});

router.get('/delete/:id',(req,res)=>{
    CityModel.findByIdAndRemove(req.params.id, (err, doc)=>{
        if(!err){
            res.redirect('/city/list');
        }
        else{
            console.log('Error during deleting a record', err);
        }
    });
})

function handleValidationError(err,body)
{
    for(field in err.errors)
    {
        switch (err.errors[field].path){
            case 'fullName':
                body['fullNameError'] = err.errors[field].message;
            case 'email':
                body['emailError'] = err.errors[field].message;
            default:
                break;
        }

    }
}


function insertCityrecord(req,res){
    var city = new CityModel();
    city.id = 1001;
    city.price = 10;
    city.status = 'new';
    city.city = 'Hallo';
    city.save((err,doc)=> {
        if(!err)
        res.redirect('city/citylist');
        else{
            if(err.name=='ValidationError')
            {
                handleValidationError(err,req.body);
                res.render("city/addOrEdit",
                {
                    viewTitle:"Insert city",
                    city:req.body
                });
            }
            console.log('Error during record insertion:'+ err);
        }
    });
    
}
module.exports = router;